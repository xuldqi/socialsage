import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    // Enable minification and obfuscation
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true, // Remove console logs in production for security
        drop_debugger: true,
      },
      format: {
        comments: false, // Remove comments
      },
    },
    rollupOptions: {
      input: {
        // Entry 1: The React App (Side Panel)
        main: resolve(__dirname, 'index.html'),
        // Entry 2: The Service Worker
        background: resolve(__dirname, 'background.ts'),
        // Entry 3: The Content Script (Injected logic)
        content_script: resolve(__dirname, 'content_script.ts'),
      },
      output: {
        entryFileNames: '[name].js',
        chunkFileNames: '[name]-[hash].js',
        assetFileNames: '[name]-[hash].[ext]',
      },
    },
  },
});