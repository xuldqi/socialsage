import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Persona, SocialPost, AutoRule, AiModelId, ContentBlueprint, AgentResponse, PageData, PromptTemplate, MemoryItem, SemanticElement, AgentAction, ChatMessage } from "../types";

// --- SYSTEM CONFIGURATION (FOR RELEASE) ---

/**
 * 🔑 SYSTEM API KEYS POOL (BACKEND / FALLBACK KEYS)
 * 
 * INSTRUCTIONS FOR RELEASE:
 * 1. Add your Google Gemini API Keys in the array below.
 * 2. You can add multiple keys. The system will randomly select one to distribute load.
 * 3. These keys are used when the user has NOT provided their own "Custom API Key" in settings.
 */
const SYSTEM_API_KEYS = [
    process.env.API_KEY,      // Auto-injected environment key (if available)
    // "AIzaSy...YourKeyHere_1", 
    // "AIzaSy...YourKeyHere_2", 
].filter(k => !!k) as string[];

const DAILY_LIMIT = 50; // Set free tier limit (e.g. 50 requests per day)
const STORAGE_KEY = 'socialsage_daily_quota';

// Localized Error Messages for Quota
const QUOTA_MESSAGES: Record<string, string> = {
    en: "Today's free quota is used up. To continue, please switch to a private API key in Settings.",
    zh: "今日免费额度已用完。如需继续使用，请在设置内切换为私有 API Key。",
    ja: "本日の無料枠を使い切りました。継続して使用するには、設定でプライベートAPIキーに切り替えてください。"
};

export interface AIConfig {
  apiKey?: string;
  baseUrl?: string;
  customModel?: string;
  signal?: AbortSignal;
  outputLanguage?: string; // 'en' | 'zh' | 'ja' etc.
}

// --- QUOTA MANAGEMENT ---

const checkDailyQuota = (): boolean => {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (!data) return true;
        
        const { date, count } = JSON.parse(data);
        const today = new Date().toDateString();
        
        if (date !== today) {
            // Reset for new day
            localStorage.setItem(STORAGE_KEY, JSON.stringify({ date: today, count: 0 }));
            return true;
        }
        
        return count < DAILY_LIMIT;
    } catch (e) {
        return true; // Fallback to allow if error
    }
};

const incrementDailyQuota = () => {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        const today = new Date().toDateString();
        let count = 0;

        if (data) {
            const parsed = JSON.parse(data);
            if (parsed.date === today) {
                count = parsed.count;
            }
        }
        
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ date: today, count: count + 1 }));
    } catch (e) {
        console.error("Failed to update quota", e);
    }
};

export const getRemainingQuota = (): number => {
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (!data) return DAILY_LIMIT;
        const { date, count } = JSON.parse(data);
        if (date !== new Date().toDateString()) return DAILY_LIMIT;
        return Math.max(0, DAILY_LIMIT - count);
    } catch (e) {
        return DAILY_LIMIT;
    }
};

// --- CLIENT FACTORY ---

/**
 * Gets a System Key using simple rotation/random selection to distribute load.
 */
const getSystemKey = (): string => {
    if (SYSTEM_API_KEYS.length === 0) {
        throw new Error("NO_SYSTEM_KEYS_CONFIGURED");
    }
    // Simple random selection for load balancing
    const randomIndex = Math.floor(Math.random() * SYSTEM_API_KEYS.length);
    return SYSTEM_API_KEYS[randomIndex];
};

const getAiClient = (config?: AIConfig) => {
  // Priority: 1. User Custom Key -> 2. System Key Pool
  let apiKey = config?.apiKey;
  
  // If no user key, check quota and use System Key
  if (!apiKey) {
      if (!checkDailyQuota()) {
          throw new Error("QUOTA_EXCEEDED");
      }
      apiKey = getSystemKey();
  }

  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

const trackUsageIfDefault = (config?: AIConfig) => {
    // If no custom key is provided, we assume default key is used, so we increment quota
    if (!config?.apiKey) {
        incrementDailyQuota();
    }
};

const getLanguageInstruction = (config?: AIConfig): string => {
    if (!config || !config.outputLanguage || config.outputLanguage === 'en') return '';
    
    const langMap: Record<string, string> = {
        'zh': 'Chinese (Simplified)',
        'ja': 'Japanese',
        'es': 'Spanish',
        'fr': 'French',
        'de': 'German'
    };
    
    const target = langMap[config.outputLanguage] || config.outputLanguage;
    return `\nIMPORTANT: You MUST respond in ${target}.`;
};

// --- HUMAN TOUCH GUIDELINES ---
const HUMAN_TOUCH_GUIDELINES = `
CRITICAL STYLE GUIDELINES (ANTI-AI):
1. NO STRUCTURAL TEMPLATES: Do not use "Firstly", "Secondly", "In conclusion", "To summarize". Just say what you mean.
2. NO BUZZWORDS: Avoid "Underlying logic", "Methodology", "Paradigm shift". Use simple words like "Habit", "Way of thinking".
3. COLLOQUIAL: Use short sentences. Fragments are okay. Use softening words like "Feels like", "Probably", "Kinda".
4. NO FAKE EXPERIENCE: Do not invent a backstory. Do not say "I run a blog" unless it is in the provided memory.
5. BE CONCISE: If one sentence works, don't use two.
`;

// --- HELPER FOR ROBUST JSON PARSING ---
const cleanAndParseJson = (text: string): any => {
    let cleanText = text.trim();
    // Remove markdown code blocks if present
    if (cleanText.startsWith('```')) {
        cleanText = cleanText.replace(/^```(json)?/, '').replace(/```$/, '');
    }
    return JSON.parse(cleanText);
};

const callOpenAICompatible = async (
    systemPrompt: string,
    userPrompt: string,
    config?: AIConfig,
    jsonMode: boolean = false
): Promise<string> => {
    const apiKey = config?.apiKey || '';
    const baseUrl = config?.baseUrl || 'https://api.openai.com/v1';
    const model = config?.customModel || 'gpt-3.5-turbo';
    
    let endpoint = baseUrl;
    if (!endpoint.includes('/chat/completions') && !endpoint.includes('/completions')) {
        endpoint = `${endpoint.replace(/\/$/, '')}/chat/completions`;
    }

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: model,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userPrompt }
                ],
                temperature: 0.7,
                response_format: jsonMode ? { type: "json_object" } : undefined
            }),
            signal: config?.signal
        });

        if (!response.ok) {
            const errText = await response.text();
            throw new Error(`Custom API Error: ${response.status} - ${errText.substring(0, 1000)}`);
        }

        const data = await response.json();
        return data.choices?.[0]?.message?.content || "";
    } catch (error: any) {
        if (error.name === 'AbortError') throw error;
        console.error("AI Service Error:", error);
        throw error;
    }
};

const handleApiError = (error: any, fallbackMessage: string = "Error generating AI response.", config?: AIConfig): string => {
  console.error("AI Service Error:", error);
  
  const errMsg = error instanceof Error ? error.message : String(error);
  
  // 1. Check for Quota Exceeded (Our internal error or Google's 429)
  if (errMsg.includes("QUOTA_EXCEEDED") || errMsg.includes("429")) {
      const lang = config?.outputLanguage === 'zh' ? 'zh' : config?.outputLanguage === 'ja' ? 'ja' : 'en';
      return `⚠️ ${QUOTA_MESSAGES[lang]}`;
  }

  // 2. Check for Missing System Keys
  if (errMsg.includes("NO_SYSTEM_KEYS_CONFIGURED")) {
       return "⚠️ System Misconfiguration: No API Keys available. Please set a custom key in settings.";
  }

  // 3. Provider Errors
  if (error && typeof error === 'object' && error.error && typeof error.error === 'object') {
      const inner = error.error;
      const code = inner.code || 'Unknown';
      const msg = inner.message || JSON.stringify(inner);
      if (msg.includes("Rpc failed") || msg.includes("xhr error")) {
          return "⚠️ Network Error: Unable to connect to AI Provider.";
      }
      return `⚠️ Provider Error (${code}): ${msg}`;
  }

  return fallbackMessage;
};

// --- CORE FUNCTIONS ---

export const generateReply = async (
  post: SocialPost,
  persona: Persona,
  customInstruction?: string,
  modelId: AiModelId = 'gemini-2.5-flash',
  memories: MemoryItem[] = [],
  config?: AIConfig
): Promise<string> => {
  try {
    // We only track quota if using system keys. We do this inside the try block 
    // to ensure checkDailyQuota() runs inside getAiClient().
    // However, if we want to fail fast before any logic, we can check.
    
    // Note: getAiClient checks quota. trackUsageIfDefault increments it.
    // We must track usage ONLY after a successful call or attempted call to prevent free usage loop hole?
    // Actually, simple count on attempt is safer to prevent abuse.
    if (!config?.apiKey) trackUsageIfDefault(config);

    const relevantMemories = memories.slice(0, 5).map(m => `- ${m.content}`).join('\n');
    const memoryContext = relevantMemories ? `\n\nUSER KNOWLEDGE:\n${relevantMemories}\nUse this context implicitly.` : '';

    const systemInstruction = `You are a social media pro.
    
    TARGET PERSONA:
    Tone: ${persona.tone}
    Style Sample: "${persona.exampleText}"
    ${memoryContext}
    
    ${HUMAN_TOUCH_GUIDELINES}
    
    INSTRUCTIONS:
    - Mimic the persona's style strictly.
    - Keep it concise and relevant to ${post.platform}.
    ${customInstruction ? `User Note: ${customInstruction}` : ''}
    ${getLanguageInstruction(config)}
    `;

    const prompt = `Reply to this post by ${post.author}:\n"${post.content}"`;

    if (modelId === 'custom' || modelId.startsWith('deepseek')) {
        return await callOpenAICompatible(systemInstruction, prompt, config);
    }

    const ai = getAiClient(config);
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.85,
      }
    });
    
    return response.text || "";
  } catch (error) {
    return handleApiError(error, "Error generating reply.", config);
  }
};

export const polishContent = async (
  content: string,
  persona: Persona,
  goal: 'expand' | 'shorten' | 'polish' | 'translate',
  modelId: AiModelId = 'gemini-2.5-flash',
  config?: AIConfig
): Promise<string> => {
  try {
    if (!config?.apiKey) trackUsageIfDefault(config);

    let goalInstruction = "";
    switch (goal) {
        case 'expand': goalInstruction = "Expand the text with more detail."; break;
        case 'shorten': goalInstruction = "Condense the text."; break;
        case 'polish': goalInstruction = "Improve grammar and flow, making it sound native and matching the persona's tone."; break;
        case 'translate': goalInstruction = "Translate to the target language (implied by context or settings)."; break;
    }

    const systemInstruction = `You are an expert editor.
    Adopt this tone: ${persona.tone} (${persona.name}).
    Reference Style: "${persona.exampleText}"
    
    Task: ${goalInstruction}
    ${HUMAN_TOUCH_GUIDELINES}
    ${getLanguageInstruction(config)}
    `;

    if (modelId === 'custom' || modelId.startsWith('deepseek')) {
        return await callOpenAICompatible(systemInstruction, content, config);
    }

    const ai = getAiClient(config);
    const response = await ai.models.generateContent({
      model: modelId,
      contents: content,
      config: { systemInstruction }
    });
    return response.text || "";
  } catch (error) {
    return handleApiError(error, "Error polishing content.", config);
  }
};

export const generateBlueprintContent = async (
  blueprint: ContentBlueprint,
  persona: Persona,
  modelId: AiModelId = 'gemini-2.5-flash',
  config?: AIConfig,
  language?: string
): Promise<string> => {
  try {
    if (!config?.apiKey) trackUsageIfDefault(config);

    const langInstruction = `Output Language: ${language === 'zh' ? 'Chinese (Simplified)' : language === 'ja' ? 'Japanese' : 'English'}`;

    const systemInstruction = `You are a creative social media writer.
    Persona: ${persona.name} (${persona.tone}).
    Style: "${persona.exampleText}"
    
    Goal: Write a ${blueprint.platform} ${blueprint.type} about ${blueprint.topics.join(', ')}.
    Audience: ${blueprint.audience}.
    Engagement Goal: ${blueprint.engagementGoal}.
    
    ${HUMAN_TOUCH_GUIDELINES}
    ${langInstruction}
    `;

    const prompt = blueprint.sourceMaterial 
        ? `Rewrite this source material based on the persona:\n"${blueprint.sourceMaterial}"`
        : `Create original content for the topic: ${blueprint.name}`;

    if (modelId === 'custom' || modelId.startsWith('deepseek')) {
        return await callOpenAICompatible(systemInstruction, prompt, config);
    }

    const ai = getAiClient(config);
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: { systemInstruction, temperature: 0.9 }
    });
    return response.text || "";
  } catch (error) {
    return handleApiError(error, "Error generating content.", config);
  }
};

export const processUserIntent = async (
  userMessage: string,
  currentPersonas: Persona[],
  currentRules: AutoRule[],
  modelId: AiModelId = 'gemini-2.5-flash',
  config?: AIConfig,
  pageContext?: { type?: string, url?: string, hasSelection?: boolean },
  chatHistory: ChatMessage[] = [] 
): Promise<AgentResponse> => {
  try {
    if (!config?.apiKey) trackUsageIfDefault(config);

    const systemInstruction = `You are SocialSage, a friendly, versatile, and intelligent AI assistant integrated into a browser extension.

    CORE IDENTITY:
    - You are helpful, polite, and conversational.
    - You can chat about ANYTHING (tech, life, cooking, coding).
    - You have special capabilities to control the "SocialSage" extension, but you ONLY use them if explicitly asked.
    - TERMINOLOGY: Use "Auto-Reply" (not Auto-Pilot).

    CRITICAL BEHAVIORAL RULES:
    1. NO TECHNICAL JARGON: Do not say "I have generated a JSON operation", "Config updated", or list rule IDs. Speak naturally.
    2. CHAT FIRST: If the user says "Hello", "How are you", or asks a question, JUST REPLY NORMALLY. Do NOT create rules or configs.
    3. SEMANTIC INTENT: Distinguish between "Task" (e.g., "Rewrite this text") and "Config" (e.g., "Always reply to tech posts").
        - If user gives text to improve -> Just output the improved text in 'responseMessage'.
        - If user asks to setup automation -> ONLY THEN generate 'create_rule' operations.
    4. ONBOARDING: If this is the FIRST message in history, be welcoming. Ask "How can I help you today?" instead of forcing a setup checklist.

    AVAILABLE OPERATIONS (Only use if intent is explicit):
    - create_rule / update_rule / create_persona / update_persona
    - trigger_action (extract_data, summarize_page, translate_selection)
    - start_auto_pilot (Only if user says "Start Auto-Reply" or confirms settings)

    CURRENT STATE:
    - Context: ${JSON.stringify(pageContext || {})}
    
    ${getLanguageInstruction(config)}
    `;

    // --- ONBOARDING GUARD ---
    const isFirstMessage = chatHistory.length === 0;
    const isGreeting = /^(hello|hi|hey|你好|您好|hi there)/i.test(userMessage.trim());
    if (isFirstMessage && isGreeting) {
        return {
            reasoning: "User greeted. Replying conversationally.",
            operations: [],
            responseMessage: config?.outputLanguage === 'zh' ? "您好！我是您的全能社交助手。我可以帮您自动回复消息、润色文案、或者提取网页数据。今天想先试哪一个？" : "Hello! I'm your SocialSage assistant. I can help with auto-replies, drafting, or data extraction. What would you like to do first?",
            suggestions: []
        };
    }

    const conversationContext = chatHistory
        .filter(m => m.role !== 'system')
        .slice(-10) // Keep last 10 turns for context
        .map(m => `${m.role.toUpperCase()}: ${m.content}`)
        .join('\n');
        
    const finalPrompt = conversationContext 
        ? `CHAT HISTORY:\n${conversationContext}\n\nUSER:\n${userMessage}`
        : userMessage;

    if (modelId === 'custom' || modelId.startsWith('deepseek')) {
        const jsonStr = await callOpenAICompatible(systemInstruction, finalPrompt, config, true);
        return cleanAndParseJson(jsonStr);
    }

    const ai = getAiClient(config);
    const response = await ai.models.generateContent({
      model: modelId,
      contents: finalPrompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reasoning: { type: Type.STRING },
            operations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, enum: ['create_rule', 'update_rule', 'create_persona', 'update_persona', 'trigger_action', 'update_session', 'start_auto_pilot'] },
                  payload: { 
                     type: Type.OBJECT,
                     properties: {
                        name: { type: Type.STRING, nullable: true },
                        description: { type: Type.STRING, nullable: true },
                        tone: { type: Type.STRING, nullable: true },
                        exampleText: { type: Type.STRING, nullable: true },
                        minLikes: { type: Type.NUMBER, nullable: true },
                        keywords: { type: Type.ARRAY, items: { type: Type.STRING }, nullable: true },
                        actionType: { type: Type.STRING, nullable: true },
                        action: { type: Type.STRING, nullable: true },
                        maxReplies: { type: Type.NUMBER, nullable: true },
                        customInstruction: { type: Type.STRING, nullable: true }
                     },
                     nullable: true
                  }
                }
              }
            },
            responseMessage: { type: Type.STRING },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return cleanAndParseJson(text);
  } catch (e) {
    const errMsg = handleApiError(e, "Error processing intent.", config);
    return { 
      reasoning: "Error encountered.", 
      operations: [], 
      responseMessage: errMsg.includes("QUOTA") ? errMsg : `(System) ${errMsg} - I might be having trouble connected to the AI.`,
      suggestions: []
    };
  }
};

// --- EXTRACTION / ANALYSIS TOOLS ---

export const analyzeProfileStyle = async (content: string, modelId: AiModelId, config?: AIConfig) => {
    try {
        if (!config?.apiKey) trackUsageIfDefault(config);
        const sys = `Analyze this social media profile. Return JSON: { name, description, tone, exampleText }. ${HUMAN_TOUCH_GUIDELINES}`;
        if (modelId === 'custom') return cleanAndParseJson(await callOpenAICompatible(sys, content, config, true));
        const ai = getAiClient(config);
        const res = await ai.models.generateContent({
            model: modelId, contents: content, 
            config: { systemInstruction: sys, responseMimeType: "application/json" }
        });
        return cleanAndParseJson(res.text || "{}");
    } catch (e) { console.error(e); return {}; }
};

export const analyzePostStyle = async (author: string, content: string, modelId: AiModelId, config?: AIConfig) => {
    try {
        if (!config?.apiKey) trackUsageIfDefault(config);
        const sys = `Analyze post style. Return JSON: { name: "${author}'s Style", description, tone, exampleText }. ${HUMAN_TOUCH_GUIDELINES}`;
        if (modelId === 'custom') return cleanAndParseJson(await callOpenAICompatible(sys, content, config, true));
        const ai = getAiClient(config);
        const res = await ai.models.generateContent({
            model: modelId, contents: content,
            config: { systemInstruction: sys, responseMimeType: "application/json" }
        });
        return cleanAndParseJson(res.text || "{}");
    } catch (e) { console.error(e); return {}; }
};

export const extractStructuredData = async (content: string, modelId: AiModelId, config?: AIConfig) => {
    try {
        if (!config?.apiKey) trackUsageIfDefault(config);
        const sys = "Extract key data as JSON Array. Example: [{name: '...', value: '...'}].";
        if (modelId === 'custom') return await callOpenAICompatible(sys, content, config, true);
        const ai = getAiClient(config);
        const res = await ai.models.generateContent({
            model: modelId, contents: content,
            config: { systemInstruction: sys, responseMimeType: "application/json" }
        });
        return res.text || "[]";
    } catch (e) { return "[]"; }
};

export const summarizeVideoContent = async (content: string, modelId: AiModelId, config?: AIConfig) => {
    try {
        if (!config?.apiKey) trackUsageIfDefault(config);
        const sys = "Summarize this video transcript with timestamps.";
        if (modelId === 'custom') return await callOpenAICompatible(sys, content, config);
        const ai = getAiClient(config);
        const res = await ai.models.generateContent({model: modelId, contents: content, config: { systemInstruction: sys }});
        return res.text || "";
    } catch (e) { return "Error summarizing."; }
};

export const explainSelection = async (text: string, mode: 'explain'|'translate', modelId: AiModelId, config?: AIConfig) => {
    try {
        if (!config?.apiKey) trackUsageIfDefault(config);
        let prompt = `Explain: "${text}"`;
        if (mode === 'translate') {
            prompt = `Translate to ${config?.outputLanguage === 'zh' ? 'Chinese' : 'English'}: "${text}"`;
        } else {
            // Localize explanation request
            if (config?.outputLanguage === 'zh') prompt = `解释这段文字: "${text}"`;
            else if (config?.outputLanguage === 'ja') prompt = `このテキストを説明してください: "${text}"`;
        }

        if (modelId === 'custom') return await callOpenAICompatible("Helpful Assistant", prompt, config);
        const ai = getAiClient(config);
        const res = await ai.models.generateContent({model: modelId, contents: prompt});
        return res.text || "";
    } catch (e) { return "Error processing."; }
};

export const chatWithPage = async (question: string, pageData: PageData, modelId: AiModelId, config?: AIConfig) => {
    return ""; 
};

export const planPageInteraction = async (intent: string, elements: SemanticElement[], modelId: AiModelId, config?: AIConfig): Promise<AgentAction[]> => {
    try {
        if (!config?.apiKey) trackUsageIfDefault(config);
        const sys = `You are a Browser Agent. Map intent to actions (click, fill). Elements: ${JSON.stringify(elements)}. Return JSON Array of AgentAction.`;
        if (modelId === 'custom') return cleanAndParseJson(await callOpenAICompatible(sys, intent, config, true));
        const ai = getAiClient(config);
        const res = await ai.models.generateContent({
            model: modelId, contents: intent,
            config: { systemInstruction: sys, responseMimeType: "application/json" }
        });
        return cleanAndParseJson(res.text || "[]");
    } catch (e) { return []; }
};

export const testApiConnection = async (config: AIConfig): Promise<{ success: boolean; message?: string }> => {
    try {
        if (config.apiKey) {
            // Simple generation test
            const ai = new GoogleGenAI({ apiKey: config.apiKey });
            await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: 'Hi' });
            return { success: true };
        } 
        if (config.baseUrl) {
            await callOpenAICompatible("Test", "Hi", config);
            return { success: true };
        }
        // Fallback: If no custom key, test system key availability
        if (SYSTEM_API_KEYS.length > 0) {
            const sysKey = getSystemKey();
            const ai = new GoogleGenAI({ apiKey: sysKey });
            await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: 'Hi' });
             return { success: true, message: "Connected via System Key" };
        }

        return { success: false, message: "No configuration provided." };
    } catch (e) {
        const msg = handleApiError(e, "Connection Failed", config);
        return { success: false, message: msg };
    }
};