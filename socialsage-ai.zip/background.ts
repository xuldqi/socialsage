// background.ts
// This runs as a Service Worker in the background.

declare const chrome: any;

// Ensure the side panel opens when the user clicks the extension icon.
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error: any) => console.error(error));

// Listen for installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('SocialSage AI installed.');
});