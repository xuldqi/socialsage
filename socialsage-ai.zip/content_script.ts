import { scanPage } from './services/pageExtractor';
import { ExtensionMessage } from './types';

// content_script.ts
// This script is injected into the webpages (Twitter, etc.)

declare const chrome: any;

let debounceTimer: ReturnType<typeof setTimeout>;

// 1. Function to scan and send data to Sidebar
const captureAndSend = () => {
  try {
    const context = scanPage(document.body);
    
    // Add real URL/Title (scanPage uses window.location, but let's be explicit)
    context.metadata.url = window.location.href;
    context.metadata.title = document.title;

    chrome.runtime.sendMessage({
      type: 'CAPTURED_CONTEXT',
      payload: context,
      from: 'ContentScript',
      to: 'SidePanel'
    });
  } catch (e) {
    // Fail silently in content script to avoid console noise
  }
};

// 2. Observe DOM changes to auto-update
const observer = new MutationObserver(() => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    captureAndSend();
  }, 1000); // Debounce updates to avoid spamming
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  attributes: false // Don't trigger on simple attribute changes to save perf
});

// 3. Listen for requests from Sidebar (e.g., "Extract Now" button)
chrome.runtime.onMessage.addListener((message: ExtensionMessage, sender: any, sendResponse: any) => {
  if (message.type === 'DOM_EXTRACT') {
    captureAndSend();
    sendResponse({ status: 'scanned' });
  }
  
  if (message.type === 'UI_UPDATE' && message.payload.action === 'fill_draft') {
      // Attempt to fill the draft into the active element or find a text box
      // This is a complex heuristic, simplifying for now
      const activeEl = document.activeElement as HTMLElement;
      if (activeEl && (activeEl.tagName === 'TEXTAREA' || activeEl.getAttribute('contenteditable') === 'true')) {
          if (activeEl.tagName === 'TEXTAREA') {
              (activeEl as HTMLTextAreaElement).value = message.payload.draft || '';
          } else {
              activeEl.innerText = message.payload.draft || '';
          }
      }
  }
});

// Initial Scan on Load
setTimeout(captureAndSend, 1000);